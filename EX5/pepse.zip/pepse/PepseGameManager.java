package pepse;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.util.Vector2;
import pepse.world.*;
import pepse.world.daynight.Night;
import pepse.world.daynight.Sun;
import pepse.world.daynight.SunHalo;
import pepse.world.mushrooms.GroundForest;
import pepse.world.trees.Tree;

import java.awt.*;
import java.util.ArrayList;

/**
 * The main class of the simulator.
 * @author Yotam Suliman, Edan Topper
 * @see GameManager
 */
public class PepseGameManager extends GameManager {
    // location constants.
    private static final float LOCATION_FACTOR = 2;
    // time constants.
    private static final float NIGHT_LENGTH_FACTOR = 2;
    public static final float CYCLE_LENGTH = 30;
    /*
     *layer constants.
     */
    private static final int SKY_LAYER = Layer.BACKGROUND;
    private static final int SUN_LAYER = 1 + Layer.BACKGROUND;
    private static final int HALO_LAYER = 2 + Layer.BACKGROUND;
    private static final int LOWER_GROUND_LAYER = Layer.STATIC_OBJECTS -1;
    private static final int TREE_LAYER = Layer.STATIC_OBJECTS;
    private static final int GROUND_LAYER = Layer.STATIC_OBJECTS;
    private static final int CLOUDS_LAYER = Layer.STATIC_OBJECTS;
    private static final int MUSHROOM_LAYER = Layer.STATIC_OBJECTS;
    private static final int LEAF_LAYER = TREE_LAYER + 1;
    private static final int AVATAR_LAYER = Layer.DEFAULT;
    private static final int NIGHT_LAYER = Layer.FOREGROUND;
    // color constants.
    private static final Color HALO_COLOR = new Color(255, 255, 0, 20);
    private static final float WINDOW_CENTER_FACTOR = 0.5f;
    // fields constants.
    private static final int SEED = 3;
    // game constants.
    private static final int TARGET_FRAME = 100;
    private ImageReader imageReader;
    private UserInputListener inputListener;
    private WindowController windowController;


    /**
     * The method will be called once when a GameGUIComponent is created,
     * and again after every invocation of windowController.resetGame().
     * @param imageReader Contains a single method: readImage, which reads an image from disk.
     *                 See its documentation for help.
     * @param soundReader Contains a single method: readSound, which reads a wav file from
     *                    disk. See its documentation for help.
     * @param inputListener Contains a single method: isKeyPressed, which returns whether
     *                      a given key is currently pressed by the user or not. See its
     *                      documentation.
     * @param windowController Contains an array of helpful, self explanatory methods
     *                         concerning the window.
     */
    @Override
    public void initializeGame(ImageReader imageReader, SoundReader soundReader,
                               UserInputListener inputListener, WindowController windowController) {
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        this.imageReader = imageReader;
        this.inputListener = inputListener;
        this.windowController = windowController;
        windowController.setTargetFramerate(TARGET_FRAME);

        dayNightSkyCreate();
        worldCreate();

        gameObjects().layers().shouldLayersCollide(LEAF_LAYER, GROUND_LAYER, true);
    }

    /*
     * creates the sun, the night and sun halo.
     */
    private void dayNightSkyCreate() {
        Vector2 windowDimensions = windowController.getWindowDimensions();
        Sky.create(gameObjects(), windowDimensions, SKY_LAYER);
        GameObject sun = Sun.create(gameObjects(), SUN_LAYER,
                windowDimensions, CYCLE_LENGTH);
        SunHalo.create(gameObjects(), HALO_LAYER, sun,
                HALO_COLOR);
        Night.create(gameObjects(), NIGHT_LAYER, windowDimensions,
                CYCLE_LENGTH/NIGHT_LENGTH_FACTOR);
    }

    /*
     * create the sky , the terrain and the trees.
     */
    private void worldCreate() {
        Vector2 windowDimensions = windowController.getWindowDimensions();
        Terrain terrain = new Terrain(
                gameObjects(), GROUND_LAYER, windowDimensions, SEED);
        Clouds clouds = new Clouds(
                this.gameObjects(), CLOUDS_LAYER, SEED, terrain::groundHeightAt, imageReader);
        Tree tree = new Tree(
                gameObjects(), TREE_LAYER, SEED, terrain::groundHeightAt);
        GroundForest groundForest = new GroundForest(
                gameObjects(), MUSHROOM_LAYER, SEED, terrain::groundHeightAt, imageReader);
        //adds all the creators to the ArrayList
        ArrayList<ObjectCreator> objectCreators = new ArrayList<>();
        objectCreators.add(terrain);
        objectCreators.add(clouds);
        objectCreators.add(tree);
        objectCreators.add(groundForest);

        Vector2 avatarLocation = new Vector2(windowDimensions.x()/LOCATION_FACTOR,
                terrain.groundHeightAt(windowDimensions.x()/LOCATION_FACTOR));
        Avatar avatar = Avatar.create(gameObjects(), AVATAR_LAYER, avatarLocation,inputListener, imageReader);
        // creates the world creator
        WorldCreator worldCreator = new WorldCreator(objectCreators, avatar, gameObjects(), windowDimensions,
                LOWER_GROUND_LAYER, TREE_LAYER, LEAF_LAYER);
        gameObjects().addGameObject(worldCreator);
        
        Vector2 cameraVector = windowDimensions.mult(WINDOW_CENTER_FACTOR).add(avatarLocation.mult(-1));
        setCamera(new Camera(avatar, cameraVector, windowDimensions , windowDimensions));
    }

    /**
     * Runs the program
     * @param args Command Line args
     */
    public static void main(String [] args){
        new PepseGameManager().run();
    }
}
