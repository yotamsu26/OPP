package pepse.world;

import  danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.util.Vector2;
import pepse.world.trees.Tree;

import java.util.ArrayList;

/**
 * A game object that manages the creation and deletion of all the game
 * objects that created using ObjectCreator interface
 * @author Yotam Suliman, Edan Topper
 * @see GameObject
 */
public class WorldCreator extends GameObject {
    // screen constants.
    private final int offset;
    private final ArrayList<ObjectCreator> objectCreators;
    private int minX;
    private int maxX;
    private static final int BLOCKS_OUTSIDE_SCREEN = 10;
    // class fields.
    private final Avatar avatar;
    private final GameObjectCollection gameObjects;
    private final int lowerGroundLayer;
    private final int staticLayer;
    private final int leafLayer;


    /**
     * Constructs the worldCreator
     * @param objectCreators List of all the objets that creates objects to the game
     * @param avatar the avatar to follow
     * @param gameObjects GameObject Collection
     * @param windowDimension the window dimensions
     * @param lowerGroundLayer The lower ground layer
     * @param staticLayer the layer of the tree logs,higher ground,clouds, mushrooms
     * @param leafLayer the layer of the leaves
     */
    public WorldCreator(ArrayList<ObjectCreator> objectCreators, Avatar avatar,
                        GameObjectCollection gameObjects, Vector2 windowDimension,
                        int lowerGroundLayer, int staticLayer, int leafLayer) {
        super(Vector2.ZERO, Vector2.ZERO, null);
        //initialize the fields
        this.objectCreators = objectCreators;
        this.avatar = avatar;
        this.gameObjects = gameObjects;
        this.lowerGroundLayer = lowerGroundLayer;
        this.staticLayer = staticLayer;
        this.leafLayer = leafLayer;

        int windowDimensionX = roundToBlockSize(windowDimension.x());
        this.offset = (windowDimensionX/2 + Block.SIZE * BLOCKS_OUTSIDE_SCREEN);
        // minx is 1 screen size left to avatar, maxX is 1 screen size right to avatar
        // this fields will be kept so any time we will know that all the objects that now
        // between minX and maxX should be deleted
        this.minX = roundToBlockSize((int)this.avatar.getCenter().x() -  offset);
        this.maxX = roundToBlockSize((int)this.avatar.getCenter().x() + offset);
        // creates the game between the minx and maxX - this is the initialized game
        create(minX,maxX);
    }

    /*
     * Delete the objects that are more the one screen away from the avatar
     */
    private void delete() {
        // passes on all the trees mushrooms and clouds
        for (GameObject obj: gameObjects.objectsInLayer(staticLayer)){
            // if its tree log, leaf, or ground then check
                // deletes the objects that not between minX and maxX
                if (obj.getTopLeftCorner().x() >= this.maxX || obj.getTopLeftCorner().x() < this.minX){
                    // check if the block is in charge on leafs and if it does delete them.
                    if(obj.getTag().equals(Tree.PARENT_LOG_TREE_TAG))
                        for (GameObject gameObject : ((Block) obj).blockRelationships())
                            gameObjects.removeGameObject(gameObject, leafLayer);
                    gameObjects.removeGameObject(obj, Layer.STATIC_OBJECTS);
                }
        }
        // lower ground delete
        for (GameObject obj : gameObjects.objectsInLayer(lowerGroundLayer))
            if (obj.getCenter().x() > this.maxX || obj.getCenter().x() < this.minX)
                gameObjects.removeGameObject(obj, lowerGroundLayer);
    }

    /**
     * Follows the Avatar and responds to it location with creating and deleting the world
     * @param deltaTime The time elapsed, in seconds, since the last frame. Can
     *                  be used to determine a new position/velocity by multiplying
     *                  this delta with the velocity/acceleration respectively
     *                  and adding to the position/velocity:
     *                  velocity += deltaTime*acceleration
     *                  pos += deltaTime*velocity
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        // again - calculate the point that is one screen to the left of the avatar and same for right
        int newMinX = roundToBlockSize((int)this.avatar.getCenter().x() - offset);
        int newMaxX = roundToBlockSize((int)this.avatar.getCenter().x() + offset);
//
        // avatar moved left
        if (newMinX < minX){
            updateToLeft(newMinX, newMaxX);
        }
//        // avatar moved right
        if (newMaxX > maxX){
            updateToRight(newMinX, newMaxX);
        }

        delete();
    }

    private void updateToRight(int newMinX ,int newMaxX) {
        // cover the range that between the old maxX and the new one
        create(maxX, newMaxX);
        this.maxX = newMaxX;
        this.minX = newMinX;
    }

    private void updateToLeft(int newMinX ,int newMaxX) {
        // cover the range that between the old minX and the new one
        create(newMinX, minX);
        this.maxX = newMaxX;
        this.minX = newMinX;
    }

    private void create(int startX,int endX){
        for(ObjectCreator creator: objectCreators){
            creator.createInRange(startX,endX);
        }
    }


    /*
     * round to the closest int that divides with block size
     */
    private static int roundToBlockSize(float x){
        return (int) Math.floor(x / Block.SIZE) * Block.SIZE;
    }
}
