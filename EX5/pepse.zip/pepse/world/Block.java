package pepse.world;

import danogl.GameObject;
import danogl.components.GameObjectPhysics;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

import java.util.ArrayList;

/**
 * represents a single block.
 * @see danogl.GameObject
 * @author Yotam Suliman, Edan Topper
 */
public class Block extends GameObject {
    /**
     * Size of a single block.
     */
    public static final int SIZE = 30;
    // class fields
    private final ArrayList<GameObject> blockRelative;

    /**
     * constructor.
     * @param topLeftCorner The location of the top-left corner of the created block.
     * @param renderable A renderable to render as the block.
     */
    public Block(Vector2 topLeftCorner, Renderable renderable) {
        super(topLeftCorner, Vector2.ONES.mult(SIZE), renderable);
        this.physics().preventIntersectionsFromDirection(Vector2.ZERO);
        this.physics().setMass(GameObjectPhysics.IMMOVABLE_MASS);

        blockRelative = new ArrayList<>();
    }

    /**
     * add a game object that is relative to the block.
     * @param gameObject the game object that have relation with the block.
     */
    public void addBlockRelation(GameObject gameObject) {
        blockRelative.add(gameObject);
    }

    /**
     * Getter for the Block Relatives List
     * Used usually to remove all relative GameObjects from the game
     * when this lock is removed
     * @return relatives List
     */
    public ArrayList<GameObject> blockRelationships()
    {
        return blockRelative;
    }

}

