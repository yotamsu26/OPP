package pepse.world.trees;

import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import pepse.util.ColorSupplier;
import pepse.world.Block;
import pepse.world.ObjectCreator;

import java.awt.*;
import java.util.Objects;
import java.util.Random;
import java.util.function.Function;

/**
 * Responsible for the creation and management of trees.
 * implements the ObjectCreator interface -creating trees.
 * @author Yotam Suliman, Edan Topper
 * @see ObjectCreator
 */
public class Tree implements ObjectCreator {
    /** Tag for a log that is connected to the leafs */
    public static final String PARENT_LOG_TREE_TAG = "parent log tree";
    /** Tag for the leafs */
    public static final String TREE_LEAF_TAG = "tree leaf";
    /** Tag for a log */
    public static final String TREE_LOG_TAG = "tree log block";
    // tree size constants.
    private static final float TREE_MAX_FACTOR = (float)1/2;
    private static final float TREE_MIN_FACTOR = (float) 1/4;
    private static final float Y_LEAF_FACTOR = (float) 3/2;
    private static final int NUM_LEAF_FACTOR = 2;
    private static final int EVEN_LEAF_FACTOR = 3;
    private static final int ODD_LEAF_FACTOR = 2;
    // random constants.
    private static final int RAND_BOUND = 100;
    private static final int TREE_PROBABILITY_FACTOR = 8;
    private static final int LEAF_PROBABILITY_FACTOR = 25;
    // color constant.
    private static final Color TREE_LOG_COLOR = new Color(100, 50, 20);
    private static final Color LEAF_COLOR = new Color(50, 200, 30);
    private static final int PARENT_TREE_LOG = 1;
    // class fields.
    private final int seed;
    private final Function<Float, Float> groundHeightAt;
    private final int treeLayer;
    private final GameObjectCollection gameObjects;

    /**
     * Construct the Tree creator
     * @param gameObjects The collection of all participating game objects.
     * @param treeLayer The number of the layer to which the created tree objects should be added.
     *                  the leafs will be added in tree layer + 1
     * @param seed  A seed for a random number generator.
     * @param groundHeightAt function that receives a float and return a float.
     */
    public Tree (GameObjectCollection gameObjects,
                 int treeLayer,
                 int seed, Function<Float, Float> groundHeightAt)
    {
        this.seed = seed;
        this.gameObjects = gameObjects;
        this.treeLayer = treeLayer;
        this.groundHeightAt = groundHeightAt;
    }

    /**
     * This method creates trees in a given range of x-values.
     * @param minX The lower bound of the given range (will be rounded to a multiple of Block.SIZE).
     * @param maxX The upper bound of the given range (will be rounded to a multiple of Block.SIZE).
     */
    public void createInRange(int minX, int maxX) {
        int newMaxX = Math.floorDiv(maxX, Block.SIZE)*Block.SIZE,
                newMinX = Math.floorDiv(minX, Block.SIZE)*Block.SIZE;
        // decide if to create a tree at the x and if so then build it
        for (int x = newMinX; x < newMaxX; x+=Block.SIZE)
        {
            Random randomIfTree = new Random(Objects.hash(x, seed));
            if(randomIfTree.nextInt(RAND_BOUND) < TREE_PROBABILITY_FACTOR)
                createTreeAt(x, randomIfTree);
        }
    }
    /**
     * @param x the x Coordinate.
     * @param randomIfTree the random according to the seed.
     */
    private void createTreeAt(float x, Random randomIfTree) {
        // Calculate the limits of the possible height of the tree
        int groundHeight = (int) Math.floor(groundHeightAt.apply(x) / Block.SIZE) * Block.SIZE;
        int minTreeY = (int)(groundHeight*TREE_MIN_FACTOR/Block.SIZE),
                maxTreeY = (int)(groundHeight*TREE_MAX_FACTOR/Block.SIZE);
        int numOfTreeBlocks = randomIfTree.nextInt( maxTreeY - minTreeY) + minTreeY;

        // creates the block that is in charge on the leafs.
        Block parnetLogTree = createSingleTree(x, groundHeight, PARENT_TREE_LOG);
        parnetLogTree.setTag(PARENT_LOG_TREE_TAG);
        addLeafsToTree(numOfTreeBlocks, x, randomIfTree, groundHeight, parnetLogTree);

        // create all the tree besides the log block that in charge on the leaf.
        for (int treeNumber = 2; treeNumber < numOfTreeBlocks; treeNumber++)
            createSingleTree(x, groundHeight, treeNumber);


    }

    /*
     * Creates a single tree at given x
     */
    private Block createSingleTree(float x, int groundHeight, int treeNumber) {
        RectangleRenderable blockRender = new RectangleRenderable(TREE_LOG_COLOR);
        Block block = new Block(new Vector2(x, groundHeight - treeNumber *Block.SIZE),
                blockRender);
        block.setTag(TREE_LOG_TAG);
        gameObjects.addGameObject(block, treeLayer);

        return block;
    }

    /*
     * Adds leafs to a single tree
     */
    private void addLeafsToTree(int numOfTreeBlocks, float x,
                                Random random, int groundHeight, Block parentLogTree) {
        float numOfLeafs = numOfTreeBlocks% NUM_LEAF_FACTOR == 0?
                numOfTreeBlocks- EVEN_LEAF_FACTOR : numOfTreeBlocks - ODD_LEAF_FACTOR;
        float topLeftX =  x - ((numOfLeafs - 1) / NUM_LEAF_FACTOR) * Block.SIZE;
        float topLeftY = groundHeight - ((numOfLeafs + 1) * Y_LEAF_FACTOR) * Block.SIZE;
        // creates the leafs
        for (int blockX = 0; blockX < numOfLeafs; blockX++)
            for (int blockY = 0; blockY < numOfLeafs; blockY++)
                if (random.nextInt(RAND_BOUND) > LEAF_PROBABILITY_FACTOR)
                    createLeaf(topLeftX, topLeftY, blockX, blockY, parentLogTree);
    }

    /*
     * Creates a single leaf at given coordinates
     */
    private void createLeaf(float topLeftX, float topLeftY, int blockX, int blockY, Block parentLogTree) {
        RectangleRenderable blockRender =
                new RectangleRenderable(ColorSupplier.approximateColor(LEAF_COLOR));
        Leaf leaf = new Leaf(new Vector2(
                topLeftX + Block.SIZE * blockX, topLeftY + Block.SIZE * blockY), blockRender);
        leaf.setTag(TREE_LEAF_TAG);

        parentLogTree.addBlockRelation(leaf);
        //leaf layer is tree layer + 1
        gameObjects.addGameObject(leaf, treeLayer + 1);
    }
}
