package pepse.world.trees;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.components.ScheduledTask;
import danogl.components.Transition;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import pepse.world.Block;
import pepse.world.Terrain;

import java.util.Random;

/**
 * represents a single leaf.
 * @author Yotam Suliman, Edan Topper
 * @see GameObject
 */
public class Leaf extends GameObject {
    // Transitions factors.
    private static final float LEAF_ANGLE = 15f;
    private static final float TRANSITION_TIME_1 = 1f;
    private static final int TRANSITION_TIME_2 = 2;
    private static final int LEAF_SIZE_CHANGE = 3;
    private static final int BOUND_DELAY = 50;
    private static final float DELAY_FACTOR = 0.1f;
    private static final float FADEOUT_TIME = 12f ;
    private static final int VELOCITY_FACTOR = 70;
    private static final float VELOCITY_BOUND = 50f;
    // Random constants.
    private static final int BOUND = 200;
    private static final int WAIT_BOUND = 5;
    // Color constants.
    private static final int OPAQUENESS = 1;

    // class fields.
    private int lifeTime;
    private final Vector2 initialCenter;
    private Transition<Float> horizontalTransition;

    /**
     * constructor.
     * Constructs a single leaf
     *
     * @param topLeftCorner The location of the top-left corner of the created block.
     * @param renderable    A renderable to render as the block.
     */
    public Leaf(Vector2 topLeftCorner, Renderable renderable) {
        super(topLeftCorner, Vector2.ONES.mult(Block.SIZE), renderable);
        this.lifeTime = new Random().nextInt(BOUND);
        this.initialCenter = this.getCenter();
        // task that starts the leaf fall
        new ScheduledTask(this, lifeTime, false, this::leafFall);
        // task that starts the swinging of the leaf
        Random random = new Random();
        new ScheduledTask(this,
                random.nextInt(BOUND_DELAY)* DELAY_FACTOR,
                false,
                ()->creatLeafTransitions(this));
    }

    /*
     * mange all the operations when a leaf is start to fall.
     */
    private void leafFall() {
        this.transform().setVelocity(Vector2.DOWN.mult(VELOCITY_FACTOR));
        int waitingTime = new Random().nextInt(WAIT_BOUND);
        // starts the horizontal movement of the leaf when fallen
        this.horizontalTransition = new Transition<>(
                this,
                this.transform()::setVelocityX,
                -VELOCITY_BOUND,
                VELOCITY_BOUND,
                Transition.CUBIC_INTERPOLATOR_FLOAT,
                Leaf.TRANSITION_TIME_2,
                Transition.TransitionType.TRANSITION_BACK_AND_FORTH,
                null
        );
        this.renderer().fadeOut(FADEOUT_TIME, ()-> new ScheduledTask(
                this, waitingTime, false, this::regenerate));

    }
    /*
     * regenerate the leaf, after the died time.
     */
    private void regenerate() {
        this.transform().setVelocity(Vector2.ZERO);
        this.setCenter(this.initialCenter);
        this.renderer().setOpaqueness(OPAQUENESS);
        this.lifeTime = new Random().nextInt(BOUND);
        // task that starts the leaf fall
        new ScheduledTask(this, lifeTime, false, this::leafFall);
    }

    /**
     *
     * @param other The GameObject with which a collision occurred.
     * @param collision Information regarding this collision.
     *                  A reasonable elastic behavior can be achieved with:
     *                  setVelocity(getVelocity().flipped(collision.getNormal()));
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if(other.getTag().equals(Terrain.GROUND_NAME_TAG)){
            this.removeComponent(this.horizontalTransition);
            //stop the leaf from moving after it hit the ground
            new ScheduledTask(
                    this, 0.01f, false,
                    ()->this.setVelocity(Vector2.ZERO));
        }
    }

    /*
     * create the transitions of the leaf.
     */
    private void creatLeafTransitions(GameObject block) {
        // angle change transition
        new Transition<>(block,
                block.renderer()::setRenderableAngle,
                -LEAF_ANGLE,
                LEAF_ANGLE,
                Transition.LINEAR_INTERPOLATOR_FLOAT,
                TRANSITION_TIME_1,
                Transition.TransitionType.TRANSITION_BACK_AND_FORTH,
                null);
        // size change transition
        new Transition<>(block,
                block::setDimensions,
                Vector2.ONES.mult(Block.SIZE - LEAF_SIZE_CHANGE),
                Vector2.ONES.mult(Block.SIZE + LEAF_SIZE_CHANGE),
                Transition.LINEAR_INTERPOLATOR_VECTOR,
                TRANSITION_TIME_1,
                Transition.TransitionType.TRANSITION_BACK_AND_FORTH,
                null);
    }
}