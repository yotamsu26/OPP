package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.rendering.ImageRenderable;
import danogl.util.Vector2;

import java.util.Objects;
import java.util.Random;
import java.util.function.Function;

/**
 * Responsible for the creation and management of clouds.
 * implements the ObjectCreator interface
 * @author Yotam Suliman, Edan Topper
 * @see ObjectCreator
 */
public class Clouds implements ObjectCreator {
    // random constants.
    private static final int HEIGHT_RANDOM = 4;
    private static final int SEED_FACTOR = 1;
    private static final int RAND_BOUND = 100;
    private static final int CLOUD_PROBABILITY_FACTOR = 13;
    // size constants.
    private static final int FACTOR = 5;
    // clouds path string
    private static final String CLOUD_IMAGE_PATH = "assets/clouds.png";
    // size constants.
    private static final float CLOUD_WIDTH = 80;
    private static final float CLOUD_HEIGHT = 50;
    // class fields.
    private final GameObjectCollection gameObjects;
    private final int seed;
    private final int cloudLayer;
    private final Function<Float, Float> groundHeightAt;
    private final ImageReader imageReader;


    /**
     * Construct the Clouds manager
     * @param gameObjects The collection of all participating game objects.
     * @param cloudLayer The number of the layer to which the created ground objects should be added.
     * @param seed A seed for a random number generator.
     * @param groundHeightAt function that receives a float and return a float.
     * @param imageReader Image reader
     */
    public Clouds ( GameObjectCollection gameObjects,
                 int cloudLayer,
                 int seed, Function<Float, Float> groundHeightAt,
                 ImageReader imageReader)
    {
        this.gameObjects = gameObjects;
        this.seed = seed;
        this.cloudLayer = cloudLayer;
        this.groundHeightAt = groundHeightAt;
        this.imageReader = imageReader;

    }


    /**
     * This method creates clouds in a given range of x-values.
     * @param minX The lower bound of the given range (will be rounded to a multiple of Block.SIZE).
     * @param maxX The upper bound of the given range (will be rounded to a multiple of Block.SIZE).
     */
    @Override
    public void createInRange(int minX, int maxX) {
        int newMaxX = Math.floorDiv(maxX, Block.SIZE)*Block.SIZE,
                newMinX = Math.floorDiv(minX, Block.SIZE)*Block.SIZE;

        for (int x = newMinX; x < newMaxX; x+=Block.SIZE)
        {
            Random randomIfCloud = new Random(Objects.hash(x, seed + SEED_FACTOR));
            if(randomIfCloud.nextInt(RAND_BOUND) < CLOUD_PROBABILITY_FACTOR)
            {
                int groundHeight = (int) Math.floor(groundHeightAt.apply((float)x) / Block.SIZE) * Block.SIZE;

                ImageRenderable imageRenderable = imageReader.readImage(CLOUD_IMAGE_PATH,
                        true);
                int heightFactor = randomIfCloud.nextInt(HEIGHT_RANDOM);
                GameObject clouds = new GameObject(
                        new Vector2(x, groundHeight/(heightFactor+FACTOR) - Clouds.CLOUD_HEIGHT),
                        new Vector2(CLOUD_WIDTH,CLOUD_HEIGHT),
                        imageRenderable);
                gameObjects.addGameObject(clouds, cloudLayer);
            }
        }
    }
}
