package pepse.world.mushrooms;

import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.rendering.ImageRenderable;
import danogl.util.Vector2;
import pepse.world.Block;
import pepse.world.ObjectCreator;

import java.util.Objects;
import java.util.Random;
import java.util.function.Function;

/**
 * Responsible for the creation and management of Mushrooms.
 * implements the ObjectCreator interface -creating mushrooms.
 * @author Yotam Suliman, Edan Topper
 * @see ObjectCreator
 */
public class GroundForest implements ObjectCreator {
    // mushroom constants.
    private static final String MUSHROOM_IMAGE_PATH = "assets/mushroom.png";
    private static final int MUSHROOMS_PROBABILITY_FACTOR = 5;
    private static final int RAND_BOUND = 100;
    private static final int SEED_FACTOR = 2;

    private final int seed;
    private final GameObjectCollection gameObjects;
    private final int mushroomLayer;
    private final Function<Float, Float> groundHeightAt;
    private final ImageReader imageReader;

    /**
     * Construct the mushroom creator
     * @param gameObjects The collection of all participating game objects.
     * @param mushroomLayer The number of the layer to which the created mushroom objects should be added.
     * @param seed  A seed for a random number generator.
     * @param groundHeightAt function that receives a float and return a float.
     * @param imageReader ImageReader
     */
    public GroundForest(GameObjectCollection gameObjects,
                        int mushroomLayer,
                        int seed, Function<Float, Float> groundHeightAt,
                        ImageReader imageReader)
    {
        this.seed = seed;
        this.gameObjects = gameObjects;
        this.mushroomLayer = mushroomLayer;
        this.groundHeightAt = groundHeightAt;
        this.imageReader = imageReader;
    }

    /**
     * This method creates mushrooms in a given range of x-values.
     * @param minX The lower bound of the given range (will be rounded to a multiple of Block.SIZE).
     * @param maxX The upper bound of the given range (will be rounded to a multiple of Block.SIZE).
     */
    @Override
    public void createInRange(int minX, int maxX) {
        int newMaxX = Math.floorDiv(maxX, Block.SIZE)*Block.SIZE,
                newMinX = Math.floorDiv(minX, Block.SIZE)*Block.SIZE;
        // decide if to create a tree at the x and if so then build it
        for (int x = newMinX; x < newMaxX; x+=Block.SIZE)
        {
            Random randomIfTree = new Random(Objects.hash(x, seed + SEED_FACTOR));
            if (randomIfTree.nextInt(RAND_BOUND) < MUSHROOMS_PROBABILITY_FACTOR)
                createMushroomAt(x);
        }
    }

    /*
     * Creates a single mushroom at
     */
    private void createMushroomAt(float x) {
        int groundHeight = (int) Math.floor(groundHeightAt.apply(x) / Block.SIZE) * Block.SIZE;

        ImageRenderable imageRenderable = imageReader.readImage(MUSHROOM_IMAGE_PATH,
                true);
        Mushroom mushroom = new Mushroom(new Vector2(x, groundHeight - Block.SIZE), imageRenderable);
        gameObjects.addGameObject(mushroom, mushroomLayer);
    }
}
