package pepse.world.mushrooms;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import pepse.world.Avatar;
import pepse.world.Block;

/**
 * represents a single mushroom in the game.
 * @author Yotam Suliman, Edan Topper
 * @see GameObject
 */
public class Mushroom extends GameObject {
    // velocity constants.
    private static final float FLIP = -1f;
    // tag name constants.
    private static final String MUSHROOM_TAG_NAME = "mushroom";

    /**
     * Constructs a new mushroom with Block.size Size
     * @param topLeftCorner The location of the top-left corner of the created Mushroom.
     * @param renderable A renderable to render as the block.
     */
    public Mushroom (Vector2 topLeftCorner, Renderable renderable)
    {
        super(topLeftCorner, Vector2.ONES.mult(Block.SIZE), renderable);
        this.setTag(MUSHROOM_TAG_NAME);
    }

    /**
     * flipped the velocity in collision.
     * @param other The GameObject with which a collision occurred.
     * @param collision Information regarding this collision.
     *                  A reasonable elastic behavior can be achieved with:
     *                  setVelocity(getVelocity().flipped(collision.getNormal()));
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if (other.getTag().equals(Avatar.AVATAR_TAG_NAME) && other.getVelocity().y() > 0) {
            other.setVelocity(other.getVelocity().mult(FLIP));
        }
    }
}
