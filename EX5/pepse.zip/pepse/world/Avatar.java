package pepse.world;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.components.CoordinateSpace;
import danogl.gui.ImageReader;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.*;
import danogl.util.Vector2;

import java.awt.event.KeyEvent;

/**
 * An avatar can move around the world.
 * @author Yotam Suliman, Edan Topper
 * @see GameObject
 */
public class Avatar extends GameObject{
    /**
     * Avatar tag
     */
    public static final String AVATAR_TAG_NAME = "avatar";
    // font constants.
    private static final String INITIAL_STRING ="ENERGY : 100";
    private static final String FONT_NAME = "Monospaced";
    private static final String ENERGY_STRING = "ENERGY : ";
    // images constants.
    private static final String[] STANDING_IMAGES = {"assets/AnimationSheet_Character1.png",
            "assets/AnimationSheet_Character2.png"};
    private static final String[] FLYING_IMAGES = {"assets/flying1.png",
            "assets/flying2.png", "assets/flying3.png"};
    private static final String[] WALKING_IMAGES = {"assets/walking1.png", "assets/walking2.png",
            "assets/walking3.png"};
    private static final String[] JUMP_IMAGES = {"assets/jump1.png", "assets/jump2.png",
            "assets/jump3.png"};
    private static final float CLIP_TIME = 0.2f;
    // Avatar constants.
    private static final float AVATAR_SIZE = 70;
    private static final float VELOCITY_FACTOR = 200;
    // jump constants.
    private static final float ACCELERATION_SPEED = 500;
    private static final float JUMP_VELOCITY = 300;
    // energy constants.
    private static final int INITIAL_ENERGY = 100;
    private static final float ENERGY_UPDATE_FACTOR = 0.5f;
    private static final float ENERGY_BLOCK_SIZE = 40;
    //fields
    private float energy;
    private final TextRenderable energyLevelRender;
    private boolean lookLeft = true;
    // static fields.
    private static UserInputListener userInputListener;
    private static AnimationRenderable standingAnimation;
    private static AnimationRenderable walkingAnimation;
    private static AnimationRenderable flyingAnimation;
    private static AnimationRenderable jumpAnimation;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     *                      the GameObject will not be rendered.
     * @param energyLevelRender the render-able of the energy level
     */
    public Avatar(Vector2 topLeftCorner, Vector2 dimensions,
                  Renderable renderable, TextRenderable energyLevelRender) {
        super(topLeftCorner, dimensions, renderable);
        physics().preventIntersectionsFromDirection(Vector2.ZERO);

        this.transform().setAccelerationY(Vector2.DOWN.y()*ACCELERATION_SPEED);
        this.energy = INITIAL_ENERGY;
        this.energyLevelRender = energyLevelRender;
        this.setTag(AVATAR_TAG_NAME);
    }

    /**
     *
     * @param deltaTime The time elapsed, in seconds, since the last frame. Can
     *                  be used to determine a new position/velocity by multiplying
     *                  this delta with the velocity/acceleration respectively
     *                  and adding to the position/velocity:
     *                  velocity += deltaTime*acceleration
     *                  pos += deltaTime*velocity
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);

        this.transform().setVelocityX(0);
        if (getVelocity().y() >= 0)
            this.renderer().setRenderable(standingAnimation);
        else
            this.renderer().setRenderable(jumpAnimation);
        if(userInputListener.isKeyPressed(KeyEvent.VK_LEFT))
            leftSideKey();
        if (userInputListener.isKeyPressed(KeyEvent.VK_RIGHT))
            rightSideKey();
        if (userInputListener.isKeyPressed(KeyEvent.VK_SPACE) && getVelocity().y() == 0)
            jumpFunc();
        if (userInputListener.isKeyPressed(KeyEvent.VK_SPACE) &&
                userInputListener.isKeyPressed(KeyEvent.VK_SHIFT) && energy > 0)
            flyFunc();
        if (getVelocity().y() == 0 && energy < INITIAL_ENERGY) {
            energy += ENERGY_UPDATE_FACTOR;
            this.energyLevelRender.setString(ENERGY_STRING + energy);
        }
    }
    /*
     * manging the fly operations when shift and space are pressed together.
     */
    private void flyFunc() {
        energy -= ENERGY_UPDATE_FACTOR;
        this.energyLevelRender.setString(ENERGY_STRING + energy);

        setVelocity(new Vector2(this.getVelocity().x(),-JUMP_VELOCITY));
        this.renderer().setRenderable(flyingAnimation);
    }

    /**
     *
     * @param other The GameObject with which a collision occurred.
     * @param collision Information regarding this collision.
     *                  A reasonable elastic behavior can be achieved with:
     *                  setVelocity(getVelocity().flipped(collision.getNormal()));
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if(other.getTag().equals(Terrain.GROUND_NAME_TAG) && this.getVelocity().y() > 0)
            this.transform().setVelocityY(0);
    }

    /*
     * manging the operations when the right key is pressed.
     */
    private void rightSideKey() {
        this.setVelocity(this.getVelocity().add(Vector2.RIGHT.mult(VELOCITY_FACTOR)));
        if(!lookLeft){
            renderer().setIsFlippedHorizontally(lookLeft);
            lookLeft = true;
        }
        this.renderer().setRenderable(walkingAnimation);
    }

    /*
     * manging the operations when the left key is pressed.
     */
    private void leftSideKey() {
        this.setVelocity(this.getVelocity().add(Vector2.LEFT.mult(VELOCITY_FACTOR)));
        if(lookLeft) {
            renderer().setIsFlippedHorizontally(lookLeft);
            lookLeft = false;
        }
        this.renderer().setRenderable(walkingAnimation);
    }

    /*
     * make the avatar jump.
     */
    private void jumpFunc() {

        this.setVelocity(getVelocity().add(Vector2.UP.mult(JUMP_VELOCITY)));
        this.renderer().setRenderable(jumpAnimation);
    }

    /**
     * This function creates an avatar that can travel the world and is followed by the camera.
     * @param gameObjects - The collection of all participating game objects.
     * @param layer - The number of the layer to which the created avatar should be added.
     * @param topLeftCorner - The location of the top-left corner of the created avatar.
     * @param inputListener - Used for reading input from the user.
     * @param imageReader - Used for reading images from disk or from within a jar.
     * @return A newly created representing the avatar.
     */
    public static Avatar create(GameObjectCollection gameObjects,
                                int layer, Vector2 topLeftCorner,
                                UserInputListener inputListener,
                                ImageReader imageReader)
    {
        Vector2 avatarLocation = topLeftCorner.add(new Vector2(0, -AVATAR_SIZE));
        userInputListener = inputListener;

        createAnimation(imageReader);

        TextRenderable textRenderable = addEnergyText(gameObjects);

        Avatar avatar = new Avatar(avatarLocation,
                new Vector2(AVATAR_SIZE, AVATAR_SIZE), flyingAnimation, textRenderable);
        gameObjects.addGameObject(avatar, layer);
        return avatar;
    }
    /*
     * adding the energy text
     */
    private static TextRenderable addEnergyText(GameObjectCollection gameObjects) {
        TextRenderable energyLevelRender = new TextRenderable(INITIAL_STRING, FONT_NAME);
        GameObject energyLevelObject =
                new GameObject(Vector2.ZERO,
                        new Vector2(ENERGY_BLOCK_SIZE,ENERGY_BLOCK_SIZE), energyLevelRender);
        energyLevelObject.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        gameObjects.addGameObject(energyLevelObject, Layer.UI);

        return energyLevelRender;
    }

    /*
     * creates the animations renders.
     */
    private static void createAnimation(ImageReader imageReader) {
        standingAnimation = new AnimationRenderable(STANDING_IMAGES,
                imageReader, false, CLIP_TIME);
        flyingAnimation = new AnimationRenderable(FLYING_IMAGES,
                imageReader, false, CLIP_TIME);
        walkingAnimation = new AnimationRenderable(WALKING_IMAGES,
                imageReader, false, CLIP_TIME);
        jumpAnimation = new AnimationRenderable(JUMP_IMAGES,
                imageReader, false, CLIP_TIME);
    }
}
