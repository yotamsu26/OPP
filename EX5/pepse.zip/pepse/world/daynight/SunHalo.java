package pepse.world.daynight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.gui.rendering.OvalRenderable;
import danogl.util.Vector2;

import java.awt.*;

/**
 * Represents the halo of sun.
 * @author Yotam Suliman, Edan Topper
 */
public class SunHalo {

    // halo size constants.
    private static final float HALO_FACTOR = 3;

    // String constants.
    private static final String HALO_TAG_NAME = "halo";

    /**
     * This function creates a halo around a given object that represents the sun. The halo will be tied to
     * the given sun, and will always move with it.
     * @param gameObjects - The collection of all participating game objects.
     * @param layer - The number of the layer to which the created halo should be added.
     * @param sun - A game object representing the sun (it will be followed by the created game object).
     * @param color - The color of the halo.
     * @return A new game object representing the sun's halo.
     */
    public static GameObject create(
            GameObjectCollection gameObjects,
            int layer,
            GameObject sun,
            Color color)
    {
        //Creates the halo
        OvalRenderable haloRender = new OvalRenderable(color);
        GameObject halo = new GameObject(Vector2.ZERO, sun.getDimensions().mult(HALO_FACTOR), haloRender);
        halo.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        halo.setTag(HALO_TAG_NAME);
        // makes the halo follow the sun
        halo.addComponent((deltaTime -> halo.setCenter(sun.getCenter())));
        gameObjects.addGameObject(halo, layer);
        return halo;
    }

}
