package pepse.world.daynight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.components.Transition;
import danogl.gui.rendering.OvalRenderable;
import danogl.util.Vector2;

import java.awt.*;

/**
 * Represents the sun - moves across the sky in an elliptical path.
 * @author Yotam Suliman, Edan Topper
 */
public class Sun {
    // transition constants.
    private static final float FINAL_TRANSITION_VALUE = (float)(2*Math.PI);
    private static final float SCREEN_OVAL_SUN_PATH_FACTOR = 2;
    private static final float WINDOW_CENTER_FACTOR = 0.5f;
    private static final Float INITIAL_TRANSITION_VALUE = 0f;
    // sun size constant.
    private static final Vector2 SUN_SIZE_VECTOR = new Vector2(150, 150);
    // String constant.
    private static final String SUN_NAME_TAG = "sun";

    /** This function creates a yellow circle that moves in the sky
     *  in an elliptical path (in camera coordinates).
     * @param gameObjects - The collection of all participating game objects.
     * @param layer - The number of the layer to which the created sun should be added.
     * @param windowDimensions - The dimensions of the windows.
     * @param cycleLength - The amount of seconds it should take the created
     *                    game object to complete a full cycle.
     * @return A new game object representing the sun.
     */
    public static GameObject create(
            GameObjectCollection gameObjects, int layer, Vector2 windowDimensions, float cycleLength)
    {
        // Creates the Sun object
        OvalRenderable sunRender = new OvalRenderable(Color.YELLOW);
        GameObject sun = new GameObject(Vector2.ZERO, SUN_SIZE_VECTOR, sunRender);
        sun.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        sun.setTag(SUN_NAME_TAG);
        gameObjects.addGameObject(sun, layer);
        // Creates the sun elliptical route
        new Transition<>(
                sun, (degree)->sun.setCenter(calcSunPosition(windowDimensions, degree)), // the method to call
                INITIAL_TRANSITION_VALUE, FINAL_TRANSITION_VALUE, // final transition value
                Transition.LINEAR_INTERPOLATOR_FLOAT, // use a cubic interpolator
                cycleLength, Transition.TransitionType.TRANSITION_LOOP, null);

        return sun;
    }

    /*
     * Calculate an elliptical route for the sun (for a given angle)
     */
    private static Vector2 calcSunPosition(Vector2 windowDimensions, Float degree) {
        float x = (float) Math.sin(degree) * (windowDimensions.x()/SCREEN_OVAL_SUN_PATH_FACTOR);
        float y = (float) -Math.cos(degree) * (windowDimensions.y()/SCREEN_OVAL_SUN_PATH_FACTOR);
        return windowDimensions.mult(WINDOW_CENTER_FACTOR).add(new Vector2(x, y));
    }
}