package pepse.world;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import pepse.util.ColorSupplier;
import pepse.util.NoiseGenerator;

import java.awt.*;

/**
 * Responsible for the creation and management of terrain.
 * Implements the Object Creator interface
 * @author Yotam Suliman, Edan Topper
 * @see ObjectCreator
 */

public class Terrain implements ObjectCreator{
    /**
     * Tag of the ground blocks
     */
    public static final String GROUND_NAME_TAG = "ground block";
    // Terrain color constant.
    private static final Color BASE_GROUND_COLOR = new Color(212, 123, 74);
    // Terrain location constants.
    private static final int TERRAIN_DEPTH = 20;
    private static final float SIZE_FACTOR = (float)2/3;
    private static final float NOISE_MULTIPLAYER = 300;
    // class fields
    private final GameObjectCollection gameObjects;
    private final int groundLayer;
    private final float groundHeightAtX0;
    private final NoiseGenerator noiseGenerator;

    /**
     * constructor.
     * @param gameObjects The collection of all participating game objects.
     * @param groundLayer The number of the layer to which the created ground objects should be added.
     *                    The lower ground objects will be created at groundLayer - 1
     * @param windowDimensions The dimensions of the windows.
     * @param seed  A seed for a random number generator.
     */
    public Terrain(GameObjectCollection gameObjects,
                   int groundLayer, Vector2 windowDimensions,
                   int seed) {
        this.gameObjects = gameObjects;
        this.groundLayer = groundLayer;
        this.groundHeightAtX0 = windowDimensions.y()*SIZE_FACTOR;
        this.noiseGenerator = new NoiseGenerator(seed);

    }

    /**
     * This method return the ground height at a given location.
     * @param x A number.
     * @return The ground height at the given location.
     */
    public float groundHeightAt(float x) {
        double noise = this.noiseGenerator.noise(x/Block.SIZE) * NOISE_MULTIPLAYER;
        return (float) noise + groundHeightAtX0;
    }

    /**
     * This method creates terrain in a given range of x-values.
     * @param minX The lower bound of the given range (will be rounded to a multiple of Block.SIZE).
     * @param maxX The upper bound of the given range (will be rounded to a multiple of Block.SIZE).
     */
    @Override
    public void createInRange(int minX, int maxX) {
        int newMaxX = Math.floorDiv(maxX, Block.SIZE)*Block.SIZE,
                newMinX = Math.floorDiv(minX, Block.SIZE)*Block.SIZE;
        // create the ground blocks
        for (int x = newMinX; x < newMaxX; x+=Block.SIZE) {
            int minYValue = (int) (Math.floor(groundHeightAt(x) / Block.SIZE) * Block.SIZE);
            for (int y = 0; y < TERRAIN_DEPTH; y++) {
                addBlock(x, y, minYValue);
            }

        }
    }

    /**
     * add single block to the gameObjectCollection.
     */
    private void addBlock(int x, int y, int minYValue) {
        // create single ground block
        RectangleRenderable blockRender =
                new RectangleRenderable(ColorSupplier.approximateColor(BASE_GROUND_COLOR));
        Block block = new Block(new Vector2(x, minYValue + y*Block.SIZE), blockRender);
        block.setTag(GROUND_NAME_TAG);
        // leafs could only collide with the first 2 rows of ground
        // so create them at different layers
        if (y == 0 || y == 1) {
            gameObjects.addGameObject(block, groundLayer);
        }
        else {
            // lower ground is the ground layer-1
            gameObjects.addGameObject(block, groundLayer - 1);
        }
    }
}
