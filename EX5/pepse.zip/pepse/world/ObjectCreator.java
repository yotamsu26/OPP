package pepse.world;


/**
 * Interface of classes that creates objects to the game,
 * needs to implement the createInRange method
 */
public interface ObjectCreator {

    /**
     * Creates the Game objects between the min X and max X
     * @param minX The lower bound of the given range (will be rounded to a multiple of Block.SIZE).
     * @param maxX The upper bound of the given range (will be rounded to a multiple of Block.SIZE).
     */
    void createInRange(int minX, int maxX);
}
